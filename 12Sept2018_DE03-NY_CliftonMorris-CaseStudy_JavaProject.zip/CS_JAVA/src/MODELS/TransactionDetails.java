package MODELS;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TransactionDetails {
	
	// THIS IS THE DETAILS FROM THE CREDITCARD DATABASE
	protected int transID, day, month, year, ssn, branchCode, count,  noOfTrans, cust_phone;
	protected double TranVal;
	private String transType, credit_card_no, firstName, middleName, lastName, branchName, branchState,
	apt_no, street_name, cust_city, cust_state, cust_country, cust_zip, cust_email, 
	last_updated = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());;

	
	public int getTransID() {
		return transID;
	}

	public void setTransID(int transID) {
		this.transID = transID;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSSN() {
		return ssn;
	}

	public void setSSN(int ssn) {
		this.ssn = ssn;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public int getNoOfTrans() {
		return noOfTrans;
	}

	public void setNoOfTrans(int noOfTrans) {
		this.noOfTrans = noOfTrans;
	}

	public String getCreditCardNo() {
		return credit_card_no;
	}

	public void setCreditCardNo(String credit_card_no) {
		this.credit_card_no = credit_card_no;
	}

	public double getTranVal() {
		return TranVal;
	}

	public void setTranVal(double tranVal) {
		TranVal = tranVal;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchState() {
		return branchState;
	}

	public void setBranchState(String branchState) {
		this.branchState = branchState;
	}

	public String getAptNo() {
		return apt_no;
	}

	public void setAptNo(String apt_no) {
		this.apt_no = apt_no;
	}

	public String getStreetName() {
		return street_name;
	}

	public void setStreetName(String street_name) {
		this.street_name = street_name;
	}

	public String getCustCity() {
		return cust_city;
	}

	public void setCustCity(String cust_city) {
		this.cust_city = cust_city;
	}

	public String getCustState() {
		return cust_state;
	}

	public void setCustState(String cust_state) {
		this.cust_state = cust_state;
	}

	public String getCustCountry() {
		return cust_country;
	}

	public void setCustCountry(String cust_country) {
		this.cust_country = cust_country;
	}

	public String getCustZip() {
		return cust_zip;
	}

	public void setCustZip(String cust_zip) {
		this.cust_zip = cust_zip;
	}
	
	public int getCustPhone() {
		return cust_phone;
	}

	public void setCustPhone(int cust_phone) {
		this.cust_phone = cust_phone;
	}

	public String getCustEmail() {
		return cust_email;
	}

	public void setCustEmail(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getLastUpdated() {
		return last_updated;
	}

	public void setLastUpdated(String last_updated) {
		this.last_updated = last_updated;
	}

	public int getCount() {
		return count;
	}
	
	public void setCount( int count) {
		this.count = count;
	}
	
	
	
	
	
	
	
	
	
	
	
}
