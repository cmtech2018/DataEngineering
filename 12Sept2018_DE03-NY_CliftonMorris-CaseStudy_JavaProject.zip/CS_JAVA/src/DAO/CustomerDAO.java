package DAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import MODELS.TransactionDetails;
import SQLQUERIES.MySQLQueries;

public class CustomerDAO extends JDBC_readerDAO {
	
	TransactionDetails trans = null;
	

	
	public List<TransactionDetails> CustInfoByCC(String ccNo)  {
		List<TransactionDetails> clist = new ArrayList<TransactionDetails>();
		
		try {
			dbconnex();
			
			ps = dbconn.prepareStatement(MySQLQueries.CustInfoByCC);
		
		
			ps.setString(1, ccNo);
			
		
			dataout = ps.executeQuery();
		
			
			while(dataout.next()) {
				trans = new TransactionDetails();
				
				
				trans.setFirstName(dataout.getString(1));
				trans.setMiddleName(dataout.getString(2));
				trans.setLastName(dataout.getString(3));
	        	trans.setCreditCardNo(dataout.getString(4));
	        	trans.setAptNo(dataout.getString(5));
	        	trans.setStreetName(dataout.getString(6));
	        	trans.setCustCity(dataout.getString(7));
	        	trans.setCustState(dataout.getString(8));
	        	trans.setCustCountry(dataout.getString(9));
	        	trans.setCustZip(dataout.getString(10));
	        	trans.setCustPhone(dataout.getInt(11));
	        	trans.setCustEmail(dataout.getString(12));
	        	
	        	clist.add(trans);
				}
				return clist;
			
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
	    }
						
		return null;		
	}


	public void ModifyCustInfo(String first_name, String middle_name, String last_name, String street_name, 
			String apt_no, String cust_city, String cust_state, String cust_zip, String cust_country, int cust_phone, String cust_email, String ccNo)  {
			
			try {
				dbconnex();
				
				
				ps = dbconn.prepareStatement(MySQLQueries.ModifyCustInfo);
				
				
				ps.setString(1, first_name);
				ps.setString(2, middle_name);
				ps.setString(3, last_name);
				ps.setString(4, street_name);
				ps.setString(5, apt_no);
				ps.setString(6, cust_city);
				ps.setString(7, cust_state);
				ps.setString(8, cust_zip);
				ps.setString(9, cust_country);
				ps.setInt(10, cust_phone);
				ps.setString(11, cust_email);
				ps.setString(12, ccNo);
			
				 ps.executeUpdate();
				 ps.close();
				
				
				
			}
			catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
				e.printStackTrace();
		    }
							
		}
	

	
	public List<TransactionDetails> getMonthlyBill(String ccNo, int month, int year)  {
		List<TransactionDetails> clist = new ArrayList<TransactionDetails>();
		
		try {
			dbconnex();
			
			ps = dbconn.prepareStatement(MySQLQueries.DisplayMonthlyBill);
		
		
			ps.setString(1, ccNo);
			ps.setInt(2, month);
			ps.setInt(3, year);
			
			
		
			dataout = ps.executeQuery();
		
			
			while(dataout.next()) {
				trans = new TransactionDetails();
				
				
				//trans.setFirstName(dataout.getString(1));
				//trans.setMiddleName(dataout.getString(2));
				//trans.setLastName(dataout.getString(3));
				
				trans.setYear(dataout.getInt(1));
				trans.setMonth(dataout.getInt(2));
				trans.setDay(dataout.getInt(3));
				trans.setCreditCardNo(dataout.getString(4));
	        	trans.setTranVal(dataout.getDouble(5));
	        	
	        	clist.add(trans);
				}
				return clist;
			
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
	    }
						
		return null;		
	}
	
	public List<TransactionDetails> DisplayTransByDates(int year1, int year2, int month1, int month2, int day1, int day2)  {
		List<TransactionDetails> tlist = new ArrayList<TransactionDetails>();
		
		try {
			dbconnex();
			
			ps = dbconn.prepareStatement(MySQLQueries.TransByDates);
		
			ps.setInt(1, year1);
			ps.setInt(2, year2);
			ps.setInt(3, month1);
			ps.setInt(4, month2);
			ps.setInt(5, day1);
			ps.setInt(6, day2);			
		
			dataout = ps.executeQuery();
		
			
			while(dataout.next()) {
				trans = new TransactionDetails();
								
				trans.setTransID(dataout.getInt(1));
				trans.setTranVal(dataout.getDouble(2));
				trans.setYear(dataout.getInt(3));
	        	trans.setMonth(dataout.getInt(4));
	        	trans.setDay(dataout.getInt(5));

	        	tlist.add(trans);
				}
				return tlist;
			
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
	    }
						
		return null;		
	}

	

}
