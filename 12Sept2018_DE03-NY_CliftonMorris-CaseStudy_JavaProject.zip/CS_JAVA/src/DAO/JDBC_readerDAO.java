package DAO;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

// Methods for connection to cdw_sapp database (transcation & customer tables)
public abstract class JDBC_readerDAO  {
	// creates our data connection variable using the Java Datatype called "Connection"
	public Connection dbconn = null;
	
	// create a Result Set variable (this is a Data Type) to receive database query results
	public ResultSet dataout;
	
	// create a PreparedStatement variable (this is a Data Type) to restrict sql db queries
	public PreparedStatement ps;
	
	// PROTECTED METHOD TO CONNECT TO MYSQL DATABASE
	protected void dbconnex() throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException, SQLException {
		
		//CREATE DATABASE CONNECTION INSTANCE OF CLASS.forName (default obj.method)
		//Class.forName("com.mysql.jdbc.Driver").newInstance();
		Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
		//CREATE MEW FILE READER INSTANCE TO ACCESS DB CONNECTION CREDENTIALS
		FileReader getdbid = new FileReader("dbcredentials.properties");
		
		// CREATE PROPERTIES OBJECT TO HOLD DATABASE CREDENTIALS PROPERTIES 
        Properties p = new Properties();
        //p loads properties WHICH IS INITIALIZED WITH BLANK INFORMATION
        p.load(getdbid);
        // CREATE THE ACTUAL CONNECITON VARIABLE USING INPUTS FROM THE PROPERTIES OBJECT (OTHERWISE YOU CAN JUST MANUALLY INPUT THE CONNECTION
        // PARAMETERS
         dbconn = DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"), p.getProperty("password"));
		
	}
	
	
	
	
	
	
	
	

}
