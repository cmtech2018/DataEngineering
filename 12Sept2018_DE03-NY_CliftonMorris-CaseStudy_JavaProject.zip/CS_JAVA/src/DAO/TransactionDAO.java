package DAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import MODELS.TransactionDetails;
import SQLQUERIES.MySQLQueries;


public class TransactionDAO extends JDBC_readerDAO {
	
	TransactionDetails trans = null;
	
	public List<TransactionDetails> DisplayTransByZip(String zipcode, int month, int year)  {
		List<TransactionDetails> tlist = new ArrayList<TransactionDetails>();
		
		try {
			dbconnex();
			
			ps = dbconn.prepareStatement(MySQLQueries.totalByZip);
		
			ps.setString(1, zipcode);
			ps.setInt(2, month);
			ps.setInt(3, year);
		
			dataout = ps.executeQuery();
		
			
			while(dataout.next()) {
				trans = new TransactionDetails();
				
				
				trans.setTransID(dataout.getInt(1));
				trans.setTransType(dataout.getString(2));
				trans.setDay(dataout.getInt(3));
	        	trans.setMonth(dataout.getInt(4));
	        	trans.setYear(dataout.getInt(5));
	        	trans.setFirstName(dataout.getString(6));
	        	trans.setMiddleName(dataout.getString(7));
	        	trans.setLastName(dataout.getString(8));

	        	tlist.add(trans);
				}
				return tlist;
			
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
	    }
						
		return null;		
	}
		
	
	//Method to Return Transaction Request
	// Method uses details from TransactionDetails Class
	public TransactionDetails DisplayTotalbyType(String transType) {
	
		try {
			//using dbconnex() method from the abstract class JDBC_readerDAO
			// to connect to the database using the specific details below
			// to run the query
			dbconnex();
			//DEFINES THE CONNECTION AS A QUERY USING "TranByTypeQuery" query
			//CLASS and sql query wrapped in String "totalByType" 
		
			ps = dbconn.prepareStatement(MySQLQueries.totalByType);
	
			ps.setString(1,transType);
		
			dataout = ps.executeQuery();
		
			trans = new TransactionDetails();
		
			if(dataout.next()) 
			{
				trans.setCount(dataout.getInt(1));
				trans.setTranVal(dataout.getInt(2));
			
				return trans;
			}
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public List<TransactionDetails> DisplayTransByState(String state)  {
		List<TransactionDetails> tlist = new ArrayList<TransactionDetails>();
		
		try {
			dbconnex();
			
			ps = dbconn.prepareStatement(MySQLQueries.totalByState);
		
			ps.setString(1, state);
		
			dataout = ps.executeQuery();
			
			while(dataout.next()) {
				trans = new TransactionDetails();
				
				
				trans.setNoOfTrans(dataout.getInt(1));
				trans.setTranVal(dataout.getDouble(2));
				trans.setTransID(dataout.getInt(3));
	        	trans.setDay(dataout.getInt(4));
	        	trans.setMonth(dataout.getInt(5));
	        	trans.setYear(dataout.getInt(6));
	        	trans.setTransType(dataout.getString(7));
	        	trans.setBranchState(dataout.getString(8));
	        	trans.setBranchName(dataout.getString(9));
	        	trans.setBranchCode(dataout.getInt(10));
	        	tlist.add(trans);
				}
				return tlist;
			
		}
		catch (SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException | IOException e) {
			e.printStackTrace();
	    }
						
		return null;		
	}

	
}
