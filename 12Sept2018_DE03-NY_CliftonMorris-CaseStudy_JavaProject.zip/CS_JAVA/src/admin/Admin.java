package admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import MODELS.TransactionDetails;

public class Admin {

	
	public static void main(String[] args)  {
		
		
		
		Scanner in = new Scanner(System.in);
		
		
		
		
		System.out.println("    WELCOME TO CM CREDIT BANK     ");
		System.out.println(" =================================");
		
		System.out.println("PLEASE SELECT AN OPTION BELOW (Enter zero('0') to exit): ");
		
		System.out.println("1 - To display the transactions made by customers living in a given"
				+ " zipcode for a given month and year. Order by day in descending order.");
		
		System.out.println("2 - To display the number and total values of transactions for a given type");
		
		System.out.println("3 - To display the number and total values of transactions for branches in a given state");
		
		System.out.println("4 - To check the existing account details of a customer: ");
		
		System.out.println("5 - To modify the existing account details of a customer: ");
		
		System.out.println("6 - To generate monthly bill for a credit card number for a given month and year: ");
		
		System.out.println("7 - To display the transactions made by a customer between two dates. Order by year, month, and day in descending order.");
		
		int choice = in.nextInt();
		 
		
		TransactionApp ta = new TransactionApp();
		
		
		for(int i = 0; ; i++) {
			
			if (choice==1) {
				ta.TransactionsByZip();
			}
			else if (choice==2) {
				ta.getTotalByType();
				
			}
			else if (choice==3) {
				ta.getTransByState();
				
			}
			else if (choice==4) {
				ta.getCustomerInfo();
				
			}
			else if (choice==5) {
				ta.modifyCustomerInfo();
				
			}
			else if (choice==6) {
				ta.getMonthlyBill();
				
			}
			else if (choice==7) {
				ta.getTransByDates();
				
			}
			else if (choice==0) {
				System.out.println("You have requested to exit. Goodbye!");
				System.exit(0);
				
			}
			else {
				System.out.println("Invalid selection. Please enter a selection from between 1 and 4");
				break;
			}
			
		}

	}

}