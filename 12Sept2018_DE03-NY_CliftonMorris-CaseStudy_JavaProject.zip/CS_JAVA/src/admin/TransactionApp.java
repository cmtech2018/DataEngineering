package admin;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import DAO.CustomerDAO;
import DAO.JDBC_readerDAO;
import DAO.TransactionDAO;
import MODELS.TransactionDetails;

public class TransactionApp   {
	
	
	public void TransactionsByZip() {
		
		try {
			
			
		Scanner in = new Scanner(System.in);
		
		System.out.println("    WELCOME TO CM CREDIT BANK     ");
		System.out.println(" =================================");
		
		System.out.println("Please enter Customer's Zipcode: ");
		String zipcode = in.nextLine();
		
		System.out.println("Enter the Month of Transaction: ");
		int month = in.nextInt();
		System.out.println("Enter Year of Transaction (in four(4) digit 'YYYY' format) ");
		int year = in.nextInt();
		int recordCnt =0;
		
		TransactionDAO td1 = new TransactionDAO();
				
		System.out.println("--------------------------------------------------------------------------");
		System.out.printf("%-15s %-15s %-6s %-8s %-7s %-12s %-17s %-11s \n", "| TRANSACITON ID |", " TRANSACTION TYPE |", " DAY |", " MONTH |", " YEAR |", " FIRSTNAME |", " MIDDLE INITIAL |", " LASTNAME |" );
		
		List<TransactionDetails> tlist = new ArrayList<TransactionDetails>(td1.DisplayTransByZip(zipcode, month, year));
		for (TransactionDetails tl : tlist) {
			System.out.printf("%-3s %-12s %-3s %-13s %-4s %-2s %-6s %-2s %-2s %-4s %-2s %-10s %-2s %-15s %-1s %-10s \n", "| ", tl.getTransID()," ", tl.getTransType(), " ", tl.getDay(), "",  tl.getMonth(), " ", tl.getYear(), " ", tl.getFirstName(), " ", tl.getMiddleName(), " ", tl.getLastName() );
			
			recordCnt++;
			
		}
		System.out.println("========================================================================================================================= ");
		System.out.println("Total Records Fetched: " + recordCnt);
		System.out.println("");
		System.out.println("");
		System.out.println("Please enter one(1) to continue or zero(0) to exit):  " );
		int exit = 1;
		exit = in.nextInt();
		if (exit==0) {
			System.out.println("You have requested to exit. Goodbye!");
			System.exit(0);
		}
			
		
		}
		catch(java.util.InputMismatchException e ) {
			System.out.println("Invalid input! You entered a value in the wrong format.");
		
		} 
	}
		

	public void getTotalByType() {
		
		try {
		
		Scanner in = new Scanner(System.in);
		System.out.println("\n");
		System.out.println("TO DISPLAY THE NUMBER AND TOTAL VALUES OF TRANSACTIONS FOR A GIVEN TYPE, " + 
							" SELECT THE TRANSACTION TYPE BELOW (OR ENTER ZERO (0) TO EXIT):  ");
		
		System.out.println(" ---- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  ----  ");
		System.out.println("");
		System.out.println("1 | Bills");
		System.out.println("2 | Education");
		System.out.println("3 | Entertainment");
		System.out.println("4 | Gas");
		System.out.println("5 | Grocery");
		System.out.println("6 | Healthcare");
		
		
		int choice = in.nextInt();
		String transType = " ";
	
		for(int i = 0; ; i++) {
			if (choice==1) {
				transType = "Bills";
				
			}
			else if (choice==2) {
				transType = "Education";
			}
			else if (choice==3) {
				transType = "Entertainment";
			}
			else if (choice==4) {
				transType = "Gas";
			}
			else if (choice==5) {
				transType = "Grocery";
			}
			else if (choice==6) {
				transType = "Healthcare";
				break;
			}
			else if (choice==0) {
				System.out.println();
				System.out.println("You have selected to exit. Goodbye!");
				System.exit(0);
			}
			else {
			System.out.println();
			System.out.println("You have entered an incorrect selection. "
					+ " Please try again");
			
				break;
		}
		
		System.out.println();
		
		TransactionDAO td2 = new TransactionDAO();
		
		TransactionDetails trans = td2.DisplayTotalbyType(transType);
		
		System.out.println("TOTAL NUMBER OF " + transType + " TRANSACTIONS IS: " + trans.getCount());
		System.out.println("TOTAL VALUE OF " + transType + " TRANSACTIONS IS: " + trans.getTranVal());
		break;
		}
		System.out.println("================================================");
		System.out.println();
		System.out.println("MAKE ANOTHER SELECTION BELOW:  ");
		
		
		}
		catch(java.util.InputMismatchException e ) {
			System.out.println("Invalid input! Enter a number between 1 and 6 or zero(0) to exit");
		
		} 
		
	}
				
	
	public void getTransByState() 	{
		
		try {
		
		Scanner in = new Scanner(System.in);
		String state = "";
		int recordCnt =0;
			if (! state.matches("[A-Za-z]+")) {
				do {
				
				
					System.out.println("");	
					System.out.println("TO DISPLAY THE NUMBER AND TOTAL VALUES OF TRANSACTIONS FOR BRANCHES IN A GIVEN STATE, "
					+ "ENTER THE TWO LETTER ABBREVIATION FOR THE STATE (e.g. - 'NY'):  " );
					System.out.println(" ---- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  ----  ");
					state = in.nextLine();
					
	
					TransactionDAO td3 = new TransactionDAO();
					
					System.out.println("--------------------------------------------------------------------------");
					System.out.printf("| "+"%16s %-22s %-22s %-19s %-6s %-8s %-7s %-15s %-14s %-14s \n",
							"TRANSACTION ID |", " NO. OF TRANSACITONS |", " TRANSACTION VALUE |", " TRANSACTION TYPE |", " DAY |", " MONTH |", " YEAR |", " BRANCH STATE |", " BRANCH NAME |", " BRANCH CODE |");
					
					List<TransactionDetails> tlist = new ArrayList<TransactionDetails>(td3.DisplayTransByState(state));
					for (TransactionDetails tl : tlist) {
						System.out.printf("%-1s %-15s %-9s %-13s %-3s %-19s %-1s %-13s %-2s %-4s %-3s %-2s %-3s %-4s %-7s %-6s %-2s %-12s %-5s %-9s \n",
								 "| ", tl.getTransID(), " ", tl.getNoOfTrans(), " ", tl.getTranVal(), "", tl.getTransType(), " ", tl.getDay(), " ", tl.getMonth(), " ", tl.getYear(), " ", tl.getBranchState(), " ", tl.getBranchName(), " ", tl.getBranchCode() );
						recordCnt++;
					}
					System.out.println(" ======================================================================================== ");
					System.out.println("Total Records Fetched: " + recordCnt);
					System.out.println("");
					
					
					System.out.println("PLEASE ENTER ONE(1) TO SELECT ANOTHER STATE OR ZERO(0) TO EXIT:  " );
					int exit = 1;
					exit = in.nextInt();
				
					if (exit==0) {
						System.out.println("You have requested to exit. Goodbye!");
						System.exit(0);
					}
					
				
				} while (! state.matches("[A-Za-z]+"));
				}else {
					System.out.println("Invalid Entry! PLEASE ENTER A TWO(2) LETTER ABBREVIATION FOR THE STATE");
				}
			

		
		
		}
		catch(java.util.InputMismatchException e ) {
			System.out.println("Invalid input! You entered a value in the wrong format.");
		
		} 
		
	}
		
	
	public void getCustomerInfo() 	{
		
		 try {
			 
			 Scanner in = new Scanner(System.in);
			 String ccNo = "";
			 int ccLength = ccNo.length();
		
			 if (! ccNo.matches("[0-9]+")) {
					do {			
						System.out.println("TO CHECK THE EXISTING ACCOUNT DETAILS OF A CUSTOMER, ENTER THEIR CREDIT CARD NUMBER BELOW: ");
						ccNo = in.nextLine();
						
						
						CustomerDAO cd1 = new CustomerDAO();
						
						System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%15s %-15s %-15s %-20s %8s %15s %-15s %5s %10s %10s %10s %15s \n",
								"| FIRST NAME | ", "MIDDLE NAME | ", "LAST NAME | ", "    CREDITCARDNO   |", "APTNo. |", "STREET NAME    |", "   CITY  |", "STATE |",
								" ZIPCODE |", "COUNTRY |", "PHONE NO. |","EMAIL ADDRESS |" );
						System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
						
						List<TransactionDetails> clist = new ArrayList<TransactionDetails>(cd1.CustInfoByCC(ccNo));
						for (TransactionDetails cl : clist) {
							System.out.printf("%-2s %-13s %-15s %-15s %-20s %-8s %-15s %-15s %-5s %10s %-10s %-10s %15s \n", 
									"| ", cl.getFirstName(), cl.getMiddleName(), cl.getLastName(), cl.getCreditCardNo(), cl.getAptNo(), cl.getStreetName(), cl.getCustCity(), cl.getCustState(), cl.getCustZip(), cl.getCustCountry(), cl.getCustPhone(), cl.getCustEmail());

						}
						System.out.println(" ======================================================================================== ");
						
						System.out.println("\n ");
						System.out.println("PLEASE ENTER ONE(1) TO REQUEST ANOTHER CUSTOMER'S ACCOUNT DETAILS OR ZERO(0) TO EXIT:  " );
						int exit = 1;
						exit = in.nextInt();
						if (exit==0) {
							System.out.println("You have requested to exit. Goodbye!");
							System.exit(0);
						}		
					} while (! ccNo.matches("[0-9]+") && !(ccLength < 16) || !(ccLength > 16));
			 }else {
						System.out.println("Invalid Entry! PLEASE ENTER THE SIXTEEN(16) DIGIT CREDIT CARD NUMBER WITHOUT SPACES");
					}
		
		 }
			catch(java.util.InputMismatchException e ) {
				System.out.println("Invalid input! You entered a value in the wrong format.");
			
			} 
	
			
	
	}
	
	
	public void modifyCustomerInfo() 	{
		
		 try {
		Scanner in = new Scanner(System.in);
		System.out.println("TO VIEW THE THE EXISTING ACCOUNT DETAILS OF A CUSTOMER'S ACCOUNT"
				+ " YOU WISH TO MODIFY, ENTER THEIR CREDIT CARD NUMBER BELOW: ");
		String ccNo = in.nextLine();
		
		CustomerDAO cd2 = new CustomerDAO();
		
		List<TransactionDetails> clist = new ArrayList<TransactionDetails>(cd2.CustInfoByCC(ccNo));
		for (TransactionDetails cl : clist) {
		
			System.out.println(" First Name: " + "\t" +  cl.getFirstName() );
			System.out.println(" Middle Name: " + "\t" +  cl.getMiddleName() );
			System.out.println(" Last Name: " + "\t" +  cl.getLastName() );
			System.out.println(" Street Name: " + "\t" +  cl.getStreetName() );
			System.out.println(" Apartment Number: " + "\t" +   cl.getAptNo() );
			System.out.println(" City: " + "\t" + "\t" +  cl.getCustCity() );
			System.out.println(" State: " + "\t" + "\t" +  cl.getCustState() );
			System.out.println(" Zipcode: " + "\t" + "\t" +  cl.getCustZip() );
			System.out.println(" Country: " + "\t" + "\t" +  cl.getCustCountry() );
			System.out.println(" Phone Number: " + "\t" +  cl.getCustPhone() );
			System.out.println(" Email Address: " + "\t" +  cl.getCustEmail() );	
		}
		System.out.println("\n");
		
		String first_name = "no data", middle_name = "no data", last_name = "no data", street_name = "no data", apt_no = "no data", cust_city = "no data", 
				cust_state = "no data", cust_zip = "no data", cust_country = "no data", cust_email = "no data";
		int cust_phone = 0;

		
	
			System.out.println("TO MODIFY THE EXISTING ACCOUNT DETAILS OF A CUSTOMER,"
					+ " ENTER THE UPDATES NEXT TO FIELD YOU WISH TO UPDATE: ");
			
			for (TransactionDetails cl : clist) {
				
				System.out.print("| First Name: " + "\t" +  cl.getFirstName() + "\t"+ "ENTER UPDATE (OR / TO SKIP): ");
				first_name = in.next();
				if (first_name.equals("/")) {
					first_name = cl.getFirstName();
				}
				System.out.println("");
				
				System.out.println("| Middle Name: " + "\t" +  cl.getMiddleName() + "\t"+ "ENTER UPDATE (OR / TO SKIP): ");
				middle_name = in.next();
				System.out.println(middle_name);
				if (middle_name.equals("/")) {
					middle_name = cl.getMiddleName();
				}
				System.out.println(middle_name);
				System.out.println("");
				System.out.println("| Last Name: " + "\t" +  cl.getLastName() + "\t"+ "ENTER UPDATE (OR / TO SKIP): ");
				last_name = in.next();
				if (last_name.equals("/")) {
					last_name = cl.getLastName();
				}
				System.out.println("");
				System.out.println("| Street Name: " + "\t" +  cl.getStreetName() + "\t"+ "ENTER UPDATE (OR / TO SKIP): " );
				street_name = in.next();
				if (street_name.equals("/")) {
					street_name = cl.getStreetName();
				}
				System.out.println("");
				System.out.println("| Apartment Number: " + "\t" +   cl.getAptNo() + "\t"+ "ENTER UPDATE (OR / TO SKIP): ");
				apt_no = in.next();
				if (apt_no.equals("/")) {
					apt_no = cl.getAptNo();
				}
				System.out.println("");
				System.out.println("| City: " + "\t" + "\t" +  cl.getCustCity() + "\t"+ "ENTER UPDATE (OR / TO SKIP): ");
				cust_city = in.next();
				if (cust_city.equals("/")) {
					cust_city = cl.getCustCity();
				}
				System.out.println("");
				System.out.println("| State: " + "\t" + "\t" +  cl.getCustState() + "\t"+ "ENTER UPDATE (OR / TO SKIP): " );
				cust_state = in.next();
				if (cust_state.equals("/")) {
					cust_state = cl.getCustState();
				}
				System.out.println("");
				System.out.println("| Zipcode: " + "\t" + "\t" +  cl.getCustZip() + "\t" + "ENTER UPDATE (OR / TO SKIP): ");
				cust_zip = in.next();
				if (cust_zip.equals("/")) {
					cust_zip = cl.getCustZip();
				}
				System.out.println("");
				System.out.println("| Country: " + "\t" + "\t" +  cl.getCustCountry() + "\t"+ "ENTER UPDATE (OR / TO SKIP): " );
				cust_country = in.next();
				if (cust_country.equals("/")) {
					cust_country = cl.getCustCountry();
				}
				System.out.println("");
				System.out.println("| Phone Number: " + "\t" +  cl.getCustPhone() + "\t" + "ENTER UPDATE (OR zero(0) TO SKIP): ");
				cust_phone = in.nextInt();
				if (cust_phone == 0) {
					cust_phone = cl.getCustPhone();
				}
				System.out.println("| Email Address: " + "\t" +  cl.getCustEmail() + "\t"+ "ENTER UPDATE (OR / TO SKIP): " );
				cust_email = in.next();
				if (cust_email.equals("/")) {
					cust_email = cl.getCustEmail();
				}
			
			}
		
		
		
			System.out.println();
		
			
			
			cd2.ModifyCustInfo(first_name, middle_name, last_name, street_name, apt_no, cust_city, cust_state,
					cust_zip, cust_country, cust_phone, cust_email, ccNo);
			
			
			List<TransactionDetails> clist2 = new ArrayList<TransactionDetails>(cd2.CustInfoByCC(ccNo));
			System.out.println("BELOW IS THE MODIFIED CUSTOMER INFORMATION: ");
			for (TransactionDetails cl : clist2) {
			
				System.out.println(" 1 | First Name: " + "\t" +  cl.getFirstName() );
				System.out.println(" 2 | Middle Name: " + "\t" +  cl.getMiddleName() );
				System.out.println(" 3 | Last Name: " + "\t" +  cl.getLastName() );
				System.out.println(" 4 | CreditCardNumber: " + "\t" +  cl.getCreditCardNo() );
				System.out.println(" 5 | Street Name: " + "\t" +  cl.getStreetName() );
				System.out.println(" 6 | Apartment Number: " + "\t" +   cl.getAptNo() );
				System.out.println(" 7 | City: " + "\t" + "\t" +  cl.getCustCity() );
				System.out.println(" 8 | State: " + "\t" + "\t" +  cl.getCustState() );
				System.out.println(" 9 | Zipcode: " + "\t" + "\t" +  cl.getCustZip() );
				System.out.println("10 | Country: " + "\t" + "\t" +  cl.getCustCountry() );
				System.out.println("11 | Phone Number: " + "\t" +  cl.getCustPhone() );
				System.out.println("12 | Email Address: " + "\t" +  cl.getCustEmail() );				
			}
			String update = in.nextLine();
			System.out.println("\n" +  "TO UPDATE ANOTHER CUSTOMER, ENTER THEIR CREDIT CARD NUMBER OR zero(0) TO EXIT: ");
		
			int exit = 1;
			exit = in.nextInt();
			if (exit==0) {
				System.out.println("You have requested to exit. Goodbye!");
				System.exit(0);
			}
		 }
			catch(java.util.InputMismatchException e ) {
				System.out.println("Invalid input! You entered a value in the wrong format.");
			
			} 
			
	}
		
	
	public void getMonthlyBill() 	{
		
		try {
		
		Scanner in = new Scanner(System.in);
		int recordCnt =0;
		String ccNo = "";
		
		
		System.out.println("");
		
			System.out.println("TO CHECK THE EXISTING ACCOUNT DETAILS OF A CUSTOMER, ENTER THEIR CREDIT CARD NUMBER BELOW: ");
			ccNo = in.nextLine();
			
			int ccLength = ccNo.length();
			if (ccLength != 16) {
				System.out.println("Invalid Entry! PLEASE ENTER THE SIXTEEN(16) DIGIT CREDIT CARD NUMBER WITHOUT SPACES"  + "\n");
				System.exit(0);
			}
			
			System.out.println("Please enter the Billing Month: ");
			int month = in.nextInt();
			if (month <= 0 || month >12) {
				System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT MONTH WITHOUT SPACES BETWEEN 1 AND 12");
				System.exit(0);
			}
			
			System.out.println("Please enter the Billing Year: ");
			int year = in.nextInt();
			if (year !=2018) {
			System.out.println("Invalid Entry! PLEASE ENTER THE FOUR(4) DIGIT YEAR WITHOUT SPACES" + "\n");
			System.exit(0);
			}
			
			
			CustomerDAO cd1 = new CustomerDAO();
			
			System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
			System.out.format("%15s %-15s %-15s %-20s %8s %15s %-15s %5s %10s %10s %10s %15s \n",
					"| FIRST NAME | ", "MIDDLE NAME | ", "LAST NAME | ", "    CREDITCARDNO   |", "APTNo. |", "STREET NAME    |", "   CITY  |", "STATE |",
					" ZIPCODE |", "COUNTRY |", "PHONE NO. |","EMAIL ADDRESS |" );
			System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
			
			List<TransactionDetails> clist = new ArrayList<TransactionDetails>(cd1.CustInfoByCC(ccNo));
			for (TransactionDetails cl : clist) {
			System.out.printf("%-15s %-15s %-15s %-20s %-8s %15s %-15s %-5s %10s %10s %10s %15s     \n", cl.getFirstName(), cl.getMiddleName(), cl.getLastName(),  
					 cl.getCreditCardNo(), cl.getAptNo(), cl.getStreetName(), cl.getCustCity(), cl.getCustState(), cl.getCustZip(),
					 cl.getCustCountry(), cl.getCustPhone(), cl.getCustEmail());
			recordCnt++;
			}
			System.out.println(" ======================================================================================== ");
			
			List<TransactionDetails> clist2 = new ArrayList<TransactionDetails>(cd1.getMonthlyBill(ccNo, month, year));
			for (TransactionDetails tl : clist2) {
			System.out.println("See your billing details below for " + tl.getMonth() + "/" +  tl.getYear() + " : ");
			System.out.println("| YEAR" + "\t" + "| MONTH" + "\t" + "| DAY" + "\t" + "| BILL TOTAL |");
			
				System.out.println("| " + tl.getYear() +"\t \t" + tl.getMonth() + "\t" + tl.getDay() + "\t" + tl.getTranVal() + " |" );
			
				System.out.println("\n" +  "TO VIEW ANOTHER CUSTOMER, ENTER THEIR CREDIT CARD NUMBER OR zero(0) TO EXIT: ");
				int exit = 1;
				exit = in.nextInt();
				if (exit==0) {
					System.out.println("You have requested to exit. Goodbye!");
					System.exit(0);
				}
				
				
			}
			
			
		
		}
		catch(java.util.InputMismatchException e ) {
			System.out.println("Invalid input! You entered a value in the wrong format.");
		
		} 
		
		
		
		
	
	}
	
	public void getTransByDates() {
		
		try {
			
			
		Scanner in = new Scanner(System.in);
		int year1 = 0;
		int year2 = 0;
		int month1 = 0;
		int month2 = 0;
		int day1 = 0;
		int day2 = 0;
		
		int yrL1 = 0;  
		int yrL2 = 0;  
		int mthL1 = 0; 
		int mthL2 = 0;   
		int dayL1 = 0;   
		int dayL2 = 0;  
		int recordCnt =0;
		
		
		
		System.out.println("Enter the Beginning and End Dates for the Transactions you wish to view:  ");
		
		System.out.print("ENTER BEGINNING YEAR:  "  );  
		year1 = in.nextInt();
		if (year1 !=2018) {
			System.out.println("Invalid Entry! PLEASE ENTER A VALID FOUR(4) DIGIT BEGINNING YEAR WITHOUT SPACES" + "\n");
			System.exit(0);
			}

		System.out.print("ENDING YEAR:  "  ); 
		year2 = in.nextInt();
		if (year2 !=2018) {
			System.out.println("Invalid Entry! PLEASE ENTER A VALID FOUR(4) DIGIT ENDING YEAR WITHOUT SPACES" + "\n");
			System.exit(0);
			}
		System.out.print("BEGINNING MONTH:  "  ); 
		month1 = in.nextInt();
		if (month1 <= 0 || month1 >12) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT BEGINNING MONTH WITHOUT SPACES BETWEEN 1 AND 12");
			System.exit(0);
		}
		System.out.print("ENDING MONTH:  "  ); 
		month2 = in.nextInt();
		if (month2 <= 0 || month2 >12) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT ENDING MONTH WITHOUT SPACES BETWEEN 1 AND 12");
			System.exit(0);
		}
		
		System.out.print("BEGINNING DAY:  "  ); 
		day1 = in.nextInt();
		if (day1 <= 0 || day1 >30) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT BEGINNING DAY WITHOUT SPACES BETWEEN 1 AND 30");
			System.exit(0);
		}
		if ( (month1 == 2 || month2 == 2) && (day1 > 28) ) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT BEGINNING DAY WITHOUT SPACES BETWEEN 1 AND 28");
			System.exit(0);
		}
		System.out.print("ENDING DAY:  "  );  
		day2 = in.nextInt();
		if (day2 < 1 || day1 > 31) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT ENDING DAY WITHOUT SPACES BETWEEN 1 AND 31");
			System.exit(0);
		}
		if ( (month1 == 2 || month2 == 2) && (day2 > 28) ) {
			System.out.println("Invalid Entry! PLEASE ENTER THE TWO(2) DIGIT ENDING DAY WITHOUT SPACES BETWEEN 1 AND 28");
			System.exit(0);
		}
		
		
		CustomerDAO cd1 = new CustomerDAO();
				
		System.out.println("--------------------------------------------------------------------------");
		System.out.printf("%-15s %-15s %-6s %-8s %-6s \n", "| TRANSACITON ID |", "| TRANSACITON VALUE |", "YEAR |", "MONTH |", "DAY |");
		
		
		List<TransactionDetails> tlist = new ArrayList<TransactionDetails>(cd1.DisplayTransByDates(year1, year2, month1, month2, day1, day2));
		for (TransactionDetails tl : tlist) {
		System.out.printf("%2s %-15s %-15s %-6s %-8s %-6s \n", "| ", tl.getTransID(), tl.getTranVal(), tl.getYear(), tl.getMonth(), tl.getDay(),"\n");
		recordCnt++;
		}
		
		
		System.out.println(" ======================================================================================== ");
		System.out.println("Total Records Fetched: " + recordCnt);
		System.out.println("");
		
	
		
		System.out.println("Please enter one(1) to continue or zero(0) to exit):  " );
		int exit = 1;
		exit = in.nextInt();
		if (exit==0) {
			System.out.println("You have requested to exit. Goodbye!");
			System.exit(0);
		}
			
	
		}
		catch(java.util.InputMismatchException e ) {
			System.out.println("Invalid input! You entered a value in the wrong format.");
		
		} 
	}


}
