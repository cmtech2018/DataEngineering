package SQLQUERIES;

public class MySQLQueries<colName> {
	
			public final static String totalByZip =
			"select cc.transaction_id, cc.transaction_type, cc.day, cc.month, cc.year, c.first_name, c.middle_name, c.last_name " +
				"from cdw_sapp_creditcard cc join cdw_sapp_customer c on cc.cust_ssn = c.ssn " +
				"where c.cust_zip = ? and cc.month = ? and cc.year = ? " +
				"order by cc.day desc";
	
	 //cc.day, cc.month, cc.year, cc.credit_card_no, cc.cust_ssn, cc.branch_code, cc.transaction_type,  cc.transaction_value

	
	public final static String totalByType =
			"select count(*), sum(transaction_value)" +
			"from CDW_SAPP_CREDITCARD " +
			"where TRANSACTION_TYPE = ? " +
			"GROUP by TRANSACTION_TYPE";


	public final static String totalByState =
			"select COUNT(cc.transaction_value), ROUND(cc.transaction_value, 2), cc.transaction_id, " + 
					"cc.day, cc.month, cc.year, cc.transaction_type, " +
					"br.branch_state, br.branch_name, br.branch_code " +
					"from CDW_SAPP_CREDITCARD cc " +
					"join CDW_SAPP_BRANCH br ON cc.branch_code=br.branch_code " +  
					"where br.branch_state = ? " +
					"group by br.branch_code " +
					"order by 1 desc";
	
	
	public final static String CustInfoByCC =
		"select  cu.first_name, cu.middle_name, cu.last_name, cc.credit_card_no, " + 
			"cu.apt_no, cu.street_name, cu.cust_city, cu.cust_state, cu.cust_country, " +
			"cu.cust_zip, cu.cust_phone, cu.cust_email "+
			"from CDW_SAPP_CREDITCARD cc " +
	        "join CDW_SAPP_CUSTOMER cu ON cc.cust_ssn=cu.ssn " +  
			"where cc.credit_card_no = ? " +
	        "group by cc.credit_card_no";
	
//CUSTOMER UPDATE QUERIES
// =========================================
	public final static String ModifyCustInfo = 
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET first_name = ?, middle_name = ?, last_name = ?, street_name = ?,  " +
			"apt_no = ?, cust_city = ?, cust_state = ?, cust_zip = ?," + 
			"cust_country = ?, cust_phone = ?, cust_email = ? where cc.credit_card_no = ?";
	
/*	
	public final static String ModifyCustFName =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET first_name = ?,  where cc.credit_card_no = ?";
	public final static String ModifyCustMName =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET middle_name = ? where cc.credit_card_no = ?";
	public final static String ModifyCustLName =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET last_name = ? where cc.credit_card_no = ?";
	public final static String ModifyCustcc =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET credit_card_no = ? where cc.credit_card_no = ?";
	public final static String ModifyCustStreet =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET street_name = ? where cc.credit_card_no = ?";
	public final static String ModifyCustApt =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET apt_no = ? where cc.credit_card_no = ?";
	public final static String ModifyCustCity =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET cust_city = ? where cc.credit_card_no = ?";
	public final static String ModifyCustState =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET cust_state = ? where cc.credit_card_no = ?";
	public final static String ModifyCustZip =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET cust_zip = ? where cc.credit_card_no = ?";
	public final static String ModifyCustCountry =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET cust_country = ? where cc.credit_card_no = ?";
	public final static String ModifyCustPhone =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET cust_phone = ? where cc.credit_card_no = ?";
	public final static String ModifyCustEmail =
			"UPDATE cdw_sapp_customer cu join CDW_SAPP_CREDITCARD cc ON cc.cust_ssn=cu.ssn " +
			"SET email = ? where cc.credit_card_no = ?";
*/	

	public final static String DisplayMonthlyBill =
			"SELECT cdw_sapp_creditcard.YEAR, cdw_sapp_creditcard.MONTH, cdw_sapp_creditcard.DAY, " +   
			"cdw_sapp_creditcard.credit_card_no, ROUND(SUM(cdw_sapp_creditcard.TRANSACTION_VALUE),2)" +  
			"from CDW_SAPP_CREDITCARD " +
		    "where credit_card_no = ? " +
		    "and month = ? " +
		    "and year = ? " +
		    "and day between 01 and 31 " +
			"GROUP BY cdw_sapp_creditcard.YEAR, cdw_sapp_creditcard.MONTH " +
			"ORDER BY cdw_sapp_creditcard.YEAR DESC, transaction_value DESC";
			
	
	public final static String TransByDates =
		"select cc.transaction_id, ROUND(cc.transaction_value, 2), cc.year, cc.month, cc.day "+
		"from CDW_SAPP_CREDITCARD cc " +  
		"where year between ? and ? " +
        "and month between ? and ? " +
        "and day between ? and ? " +
        "order by cc.year desc, cc.month desc, cc.day desc";
}

